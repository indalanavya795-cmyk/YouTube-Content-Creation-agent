import os
import ollama
from dotenv import load_dotenv

load_dotenv()

MODEL = "llama3.2"


# =========================================================
# BASIC AI FUNCTION
# =========================================================

def ask_ai(prompt):
    response = ollama.chat(
        model=MODEL,
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response["message"]["content"].strip()


# =========================================================
# INDIVIDUAL CONTENT GENERATORS
# =========================================================

def generate_video_idea(
    topic,
    audience="General audience",
    tone="Engaging"
):
    prompt = f"""
Create one strong YouTube video idea.

Topic: {topic}
Audience: {audience}
Tone: {tone}

Include:
- Video concept
- Why viewers would watch
- Main value for viewers
"""

    return ask_ai(prompt)


def generate_titles(
    topic,
    audience="General audience",
    tone="Engaging"
):
    prompt = f"""
Generate 5 catchy YouTube titles.

Topic: {topic}
Audience: {audience}
Tone: {tone}

Rules:
- Make every title different
- Make them engaging
- Avoid fake claims
- Number them 1 to 5
"""

    return ask_ai(prompt)


def generate_description(topic):
    prompt = f"""
Write a complete YouTube description for:

{topic}

Include:
- Strong opening
- What the video covers
- Viewer benefits
- Natural keywords
- Call to action
"""

    return ask_ai(prompt)


def generate_hashtags(topic):
    prompt = f"""
Generate exactly 10 relevant YouTube hashtags for:

{topic}

Return 10 hashtags.
"""

    return ask_ai(prompt)


def generate_keywords(topic):
    prompt = f"""
Generate exactly 15 SEO keywords for a YouTube video about:

{topic}

Number them from 1 to 15.
"""

    return ask_ai(prompt)


def generate_hooks(topic):
    prompt = f"""
Generate 5 strong YouTube video hooks for:

{topic}

Number them 1 to 5.
"""

    return ask_ai(prompt)


def generate_script(
    topic,
    audience="General audience",
    tone="Engaging",
    video_length="5-10 minutes",
    language="English"
):
    prompt = f"""
Write a complete YouTube video script.

Topic: {topic}
Audience: {audience}
Tone: {tone}
Video length: {video_length}
Language: {language}

Structure:

1. Hook
2. Introduction
3. Main content
4. Examples
5. Key takeaways
6. Conclusion
7. Call to action

Make the script natural for speaking.
"""

    return ask_ai(prompt)


def generate_thumbnail_ideas(topic):
    prompt = f"""
Create 5 YouTube thumbnail concepts for:

{topic}

For each concept include:
- Main visual
- Thumbnail text
- Subject/expression
- Composition
- Why it attracts attention

Number them 1 to 5.
"""

    return ask_ai(prompt)


def generate_scene_plan(
    topic,
    video_length="5-10 minutes"
):
    prompt = f"""
Create an 8-scene plan for a YouTube video.

Topic: {topic}
Video length: {video_length}

For every scene include:
- Scene number
- Visual
- Narration
- On-screen text
- Action
"""

    return ask_ai(prompt)


def generate_youtube_short(topic):
    prompt = f"""
Create a 30-60 second YouTube Shorts script about:

{topic}

Include:
- Strong hook
- Main information
- Fast pacing
- Call to action
"""

    return ask_ai(prompt)


def generate_instagram_reel(topic):
    prompt = f"""
Create a 30-60 second Instagram Reel script about:

{topic}

Include:
- Hook
- Main content
- On-screen text
- Call to action
"""

    return ask_ai(prompt)


def generate_repurposed_content(topic):
    prompt = f"""
Repurpose this YouTube topic:

{topic}

Create:

INSTAGRAM CAPTION:
Write an Instagram caption.

LINKEDIN POST:
Write a professional LinkedIn post.

PROMOTIONAL POST:
Write a promotional social-media post.

SHORT PROMOTIONAL TEXT:
Write a short promotional message.

Clearly label every section.
"""

    return ask_ai(prompt)


def generate_seo_analysis(
    topic,
    titles="",
    description="",
    keywords=""
):
    prompt = f"""
Perform a YouTube SEO analysis.

Topic:
{topic}

Titles:
{titles}

Description:
{description}

Keywords:
{keywords}

Analyze:

1. Title optimization
2. Keyword relevance
3. Description optimization
4. Search intent
5. Missing keywords
6. Improvements
7. Recommendations
"""

    return ask_ai(prompt)


# =========================================================
# COMPATIBILITY FUNCTIONS
# These names are used by web_app.py
# =========================================================

def generate_youtube_idea(
    topic,
    audience="General audience",
    tone="Engaging"
):
    return generate_video_idea(topic, audience, tone)


def generate_youtube_titles(
    topic,
    audience="General audience",
    tone="Engaging"
):
    return generate_titles(topic, audience, tone)


def generate_youtube_description(topic):
    return generate_description(topic)


def generate_youtube_hashtags(topic):
    return generate_hashtags(topic)


def generate_youtube_keywords(topic):
    return generate_keywords(topic)


def generate_youtube_script(
    topic,
    audience="General audience",
    tone="Engaging",
    video_length="5-10 minutes",
    language="English"
):
    return generate_script(
        topic,
        audience,
        tone,
        video_length,
        language
    )

def generate_scene_by_scene_script(
    topic,
    video_length="5-10 minutes"
):
    return generate_scene_plan(topic, video_length)


def generate_scene_by_scene(
    topic,
    video_length="5-10 minutes"
):
    return generate_scene_plan(topic, video_length)

def generate_youtube_shorts(topic):
    return generate_youtube_short(topic)


def generate_shorts(topic):
    return generate_youtube_short(topic)


def generate_reel(topic):
    return generate_instagram_reel(topic)


def generate_seo(
    topic,
    titles="",
    description="",
    keywords=""
):
    return generate_seo_analysis(
        topic,
        titles,
        description,
        keywords
    )


# =========================================================
# THUMBNAIL IMAGE GENERATION
# Currently available but NOT automatically called
# by the Content Factory
# =========================================================

def generate_thumbnail_image(
    prompt,
    output_path="outputs/thumbnail.png"
):
    try:
        from app.image_generator import generate_image

        return generate_image(
            prompt=prompt,
            output_path=output_path
        )

    except Exception as e:
        return f"Thumbnail image generation error: {e}"


# =========================================================
# AI CONTENT FACTORY
# ONE OLLAMA REQUEST
# =========================================================

def generate_content_factory(
    topic,
    audience="General audience",
    tone="Engaging",
    video_length="5-10 minutes",
    language="English"
):
    prompt = f"""
You are an expert YouTube content creator and SEO strategist.

Create a COMPLETE YouTube content package.

Topic: {topic}
Target audience: {audience}
Tone: {tone}
Video length: {video_length}
Language: {language}

IMPORTANT:

Generate EVERY section.

Return the response using EXACTLY these headings:

===VIDEO IDEA===

===TITLES===

===HOOKS===

===DESCRIPTION===

===HASHTAGS===

===KEYWORDS===

===FULL SCRIPT===

===THUMBNAIL CONCEPTS===

===SCENE PLAN===

===YOUTUBE SHORT===

===INSTAGRAM REEL===

===REPURPOSED CONTENT===

===SEO ANALYSIS===

Do NOT use JSON.
Do NOT use code fences.
Do NOT skip sections.

CONTENT REQUIREMENTS:

VIDEO IDEA:
Create one strong video concept and explain its value.

TITLES:
Create exactly 5 catchy titles.

HOOKS:
Create exactly 5 strong hooks.

DESCRIPTION:
Write a complete YouTube description.

HASHTAGS:
Create exactly 10 hashtags.

KEYWORDS:
Create exactly 15 SEO keywords.

FULL SCRIPT:
Write a complete script suitable for {video_length}.

THUMBNAIL CONCEPTS:
Create exactly 5 thumbnail concepts.

SCENE PLAN:
Create 8 scenes.
Include visuals, narration, on-screen text and actions.

YOUTUBE SHORT:
Create a 30-60 second Shorts script.

INSTAGRAM REEL:
Create a 30-60 second Reel script.

REPURPOSED CONTENT:
Include:
- Instagram caption
- LinkedIn post
- Promotional post
- Short promotional text

SEO ANALYSIS:
Include:
- Title analysis
- Keyword relevance
- Description analysis
- Search intent
- Missing keywords
- Improvements
- Recommendations

Generate the COMPLETE package now.
"""

    try:
        response = ollama.chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            options={
                "temperature": 0.7,
                "num_predict": 7000
            }
        )

        raw = response["message"]["content"].strip()

        sections = {
            "idea": "",
            "titles": "",
            "hooks": "",
            "description": "",
            "hashtags": "",
            "keywords": "",
            "script": "",
            "thumbnail_ideas": "",
            "scene_plan": "",
            "shorts": "",
            "reel": "",
            "repurposed": "",
            "seo": ""
        }

        heading_map = {
            "VIDEO IDEA": "idea",
            "TITLES": "titles",
            "HOOKS": "hooks",
            "DESCRIPTION": "description",
            "HASHTAGS": "hashtags",
            "KEYWORDS": "keywords",
            "FULL SCRIPT": "script",
            "THUMBNAIL CONCEPTS": "thumbnail_ideas",
            "SCENE PLAN": "scene_plan",
            "YOUTUBE SHORT": "shorts",
            "INSTAGRAM REEL": "reel",
            "REPURPOSED CONTENT": "repurposed",
            "SEO ANALYSIS": "seo"
        }

        current_section = None

        for line in raw.splitlines():

            clean_line = line.strip()

            normalized = (
                clean_line
                .replace("#", "")
                .replace("=", "")
                .strip()
                .upper()
            )

            if normalized in heading_map:
                current_section = heading_map[normalized]
                continue

            if current_section:
                sections[current_section] += line + "\n"

        for key in sections:
            sections[key] = sections[key].strip()

        # If the model did not follow headings,
        # show the complete response instead of losing it.
        filled = sum(
            1 for value in sections.values()
            if value
        )

        if filled < 5:
            sections["idea"] = raw

        return sections

    except Exception as e:

        return {
            "idea": f"Error generating content: {e}",
            "titles": "",
            "hooks": "",
            "description": "",
            "hashtags": "",
            "keywords": "",
            "script": "",
            "thumbnail_ideas": "",
            "scene_plan": "",
            "shorts": "",
            "reel": "",
            "repurposed": "",
            "seo": ""
        }


# =========================================================
# SAVE CONTENT
# =========================================================

def save_youtube_content(
    content,
    filename="youtube_content.txt"
):
    output_dir = "outputs"

    os.makedirs(output_dir, exist_ok=True)

    file_path = os.path.join(
        output_dir,
        filename
    )

    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:
        file.write(content)

    return file_path