import json
import os
from io import BytesIO

import streamlit as st

from agent import (
    generate_youtube_idea,
    generate_youtube_titles,
    generate_hooks,
    generate_youtube_description,
    generate_youtube_hashtags,
    generate_youtube_keywords,
    generate_youtube_script,
    generate_thumbnail_ideas,
    generate_scene_by_scene_script,
    generate_youtube_shorts,
    generate_instagram_reel,
    generate_repurposed_content,
    generate_seo_analysis,
    generate_content_factory,
    save_youtube_content,
)


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="AI Content Factory",
    page_icon="🎬",
    layout="wide",
)


# ============================================================
# SESSION STATE
# ============================================================

default_state = {
    "ideas": "",
    "selected_idea": "",
    "titles": "",
    "hooks": "",
    "description": "",
    "hashtags": "",
    "keywords": "",
    "script": "",
    "thumbnail_ideas": "",
    "scene_plan": "",
    "shorts": "",
    "reel": "",
    "repurposed": "",
    "seo": "",
    "factory_completed": False,
}

for key, value in default_state.items():
    if key not in st.session_state:
        st.session_state[key] = value


# ============================================================
# HISTORY
# ============================================================

HISTORY_FILE = "data/content_history.json"


def load_history():
    os.makedirs("data", exist_ok=True)

    if not os.path.exists(HISTORY_FILE):
        return []

    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception:
        return []


def save_history(project):
    os.makedirs("data", exist_ok=True)

    history = load_history()
    history.append(project)

    with open(HISTORY_FILE, "w", encoding="utf-8") as file:
        json.dump(history, file, indent=4, ensure_ascii=False)


# ============================================================
# EXPORT FUNCTIONS
# ============================================================

def create_pdf(content):
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
    )
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.enums import TA_LEFT

    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()

    title_style = styles["Title"]
    heading_style = styles["Heading2"]
    body_style = styles["BodyText"]

    story = []

    story.append(
        Paragraph("YouTube Content Package", title_style)
    )
    story.append(Spacer(1, 15))

    sections = [
        ("Video Idea", content.get("idea", "")),
        ("Titles", content.get("titles", "")),
        ("Hooks", content.get("hooks", "")),
        ("Description", content.get("description", "")),
        ("Hashtags", content.get("hashtags", "")),
        ("Keywords", content.get("keywords", "")),
        ("Script", content.get("script", "")),
        ("Thumbnail Ideas", content.get("thumbnail_ideas", "")),
        ("Scene Plan", content.get("scene_plan", "")),
        ("YouTube Short", content.get("shorts", "")),
        ("Instagram Reel", content.get("reel", "")),
        ("Repurposed Content", content.get("repurposed", "")),
        ("SEO Analysis", content.get("seo", "")),
    ]

    for heading, text in sections:
        story.append(Paragraph(heading, heading_style))
        story.append(Spacer(1, 6))

        safe_text = (
            str(text)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br/>")
        )

        story.append(Paragraph(safe_text, body_style))
        story.append(Spacer(1, 15))

    document.build(story)

    buffer.seek(0)
    return buffer


def create_docx(content):
    from docx import Document

    document = Document()

    document.add_heading(
        "YouTube Content Package",
        level=0
    )

    sections = [
        ("Video Idea", content.get("idea", "")),
        ("Titles", content.get("titles", "")),
        ("Hooks", content.get("hooks", "")),
        ("Description", content.get("description", "")),
        ("Hashtags", content.get("hashtags", "")),
        ("Keywords", content.get("keywords", "")),
        ("Script", content.get("script", "")),
        ("Thumbnail Ideas", content.get("thumbnail_ideas", "")),
        ("Scene Plan", content.get("scene_plan", "")),
        ("YouTube Short", content.get("shorts", "")),
        ("Instagram Reel", content.get("reel", "")),
        ("Repurposed Content", content.get("repurposed", "")),
        ("SEO Analysis", content.get("seo", "")),
    ]

    for heading, text in sections:
        document.add_heading(heading, level=1)
        document.add_paragraph(str(text))

    buffer = BytesIO()
    document.save(buffer)
    buffer.seek(0)

    return buffer


# ============================================================
# CONTENT PACKAGE
# ============================================================

def get_current_content():
    return {
        "idea": st.session_state.get("ideas", ""),
        "titles": st.session_state.get("titles", ""),
        "hooks": st.session_state.get("hooks", ""),
        "description": st.session_state.get("description", ""),
        "hashtags": st.session_state.get("hashtags", ""),
        "keywords": st.session_state.get("keywords", ""),
        "script": st.session_state.get("script", ""),
        "thumbnail_ideas": st.session_state.get(
            "thumbnail_ideas", ""
        ),
        "scene_plan": st.session_state.get(
            "scene_plan", ""
        ),
        "shorts": st.session_state.get("shorts", ""),
        "reel": st.session_state.get("reel", ""),
        "repurposed": st.session_state.get(
            "repurposed", ""
        ),
        "seo": st.session_state.get("seo", ""),
    }


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title("⚙️ Video Settings")

    topic = st.text_input(
        "📌 YouTube Topic",
        value="grwm",
    )

    audience = st.selectbox(
        "🎯 Target Audience",
        [
            "College Students",
            "Teenagers",
            "Young Adults",
            "Working Professionals",
            "Beginners",
            "General Audience",
            "Content Creators",
        ],
    )

    tone = st.selectbox(
        "🎭 Content Style",
        [
            "Friendly",
            "Professional",
            "Educational",
            "Funny",
            "Energetic",
            "Inspirational",
            "Storytelling",
        ],
    )

    video_length = st.selectbox(
        "⏱️ Video Length",
        [
            "Short (1–3 minutes)",
            "Medium (5–8 minutes)",
            "Long (10–15 minutes)",
            "Very Long (20+ minutes)",
        ],
    )

    language = st.selectbox(
        "🌐 Language",
        [
            "English",
            "Telugu",
            "Hindi",
            "Tamil",
            "Kannada",
            "Malayalam",
        ],
    )

    st.divider()

    st.info(
        "💡 Tip: Use a specific topic for better "
        "AI-generated content."
    )


# ============================================================
# MAIN HEADER
# ============================================================

st.title("🎬 AI Content Factory")

st.write(
    "Create an entire YouTube content package "
    "from one topic with one click."
)

st.markdown(
    """
### 🚀 How it works

**Enter one topic → Choose your settings → "
Create Complete Content → Get the entire package.**

The AI generates:

**💡 Idea → 🎯 Titles → 🪝 Hooks → 📝 Description → "
#️⃣ Hashtags → 🔑 Keywords → 📜 Script → 🖼️ Thumbnail "
"Concepts → 🎬 Scene Plan → 📱 Short → 📸 Reel → "
"🔄 Repurposed Content → 🔍 SEO Analysis**
"""
)


# ============================================================
# AI CONTENT FACTORY BUTTON
# ============================================================

st.divider()

st.subheader("🎬 Create Your Complete Content Package")

if st.button(
    "🚀 CREATE COMPLETE CONTENT",
    use_container_width=True,
    type="primary",
):

    if not topic.strip():
        st.warning(
            "Please enter a YouTube topic first."
        )

    else:

        progress = st.progress(0)
        status = st.empty()

        try:

            status.info(
                "🤖 AI is creating your complete "
                "content package..."
            )

            progress.progress(10)

            factory_result = generate_content_factory(
                topic,
                audience,
                tone,
                video_length,
                language,
            )

            progress.progress(100)

            # Store everything
            st.session_state["ideas"] = (
                factory_result.get("idea", "")
            )

            st.session_state["selected_idea"] = (
                factory_result.get("idea", "")
            )

            st.session_state["titles"] = (
                factory_result.get("titles", "")
            )

            st.session_state["hooks"] = (
                factory_result.get("hooks", "")
            )

            st.session_state["description"] = (
                factory_result.get("description", "")
            )

            st.session_state["hashtags"] = (
                factory_result.get("hashtags", "")
            )

            st.session_state["keywords"] = (
                factory_result.get("keywords", "")
            )

            st.session_state["script"] = (
                factory_result.get("script", "")
            )

            st.session_state["thumbnail_ideas"] = (
                factory_result.get(
                    "thumbnail_ideas", ""
                )
            )

            st.session_state["scene_plan"] = (
                factory_result.get(
                    "scene_plan", ""
                )
            )

            st.session_state["shorts"] = (
                factory_result.get("shorts", "")
            )

            st.session_state["reel"] = (
                factory_result.get("reel", "")
            )

            st.session_state["repurposed"] = (
                factory_result.get(
                    "repurposed", ""
                )
            )

            st.session_state["seo"] = (
                factory_result.get("seo", "")
            )

            st.session_state[
                "factory_completed"
            ] = True

            status.success(
                "🎉 Complete content package created!"
            )

        except Exception as error:

            st.session_state[
                "factory_completed"
            ] = False

            progress.empty()

            status.error(
                f"❌ Something went wrong: {error}"
            )


# ============================================================
# COMPLETE CONTENT PACKAGE DISPLAY
# ============================================================

if st.session_state.get("factory_completed"):

    st.divider()

    st.header("📦 Your Complete Content Package")

    st.success(
        "Everything below was generated from your "
        "single topic."
    )

    # --------------------------------------------------------
    # VIDEO IDEA
    # --------------------------------------------------------

    with st.expander(
        "💡 1. Video Idea",
        expanded=True,
    ):

        st.write(
            st.session_state.get(
                "ideas", ""
            )
        )

    # --------------------------------------------------------
    # TITLES
    # --------------------------------------------------------

    with st.expander(
        "🎯 2. YouTube Titles",
        expanded=True,
    ):

        st.code(
            st.session_state.get(
                "titles", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # HOOKS
    # --------------------------------------------------------

    with st.expander(
        "🪝 3. Opening Hooks",
        expanded=True,
    ):

        st.code(
            st.session_state.get(
                "hooks", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # DESCRIPTION
    # --------------------------------------------------------

    with st.expander(
        "📝 4. YouTube Description"
    ):

        st.code(
            st.session_state.get(
                "description", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # HASHTAGS
    # --------------------------------------------------------

    with st.expander(
        "#️⃣ 5. Hashtags"
    ):

        st.code(
            st.session_state.get(
                "hashtags", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # KEYWORDS
    # --------------------------------------------------------

    with st.expander(
        "🔑 6. SEO Keywords"
    ):

        st.code(
            st.session_state.get(
                "keywords", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # SCRIPT
    # --------------------------------------------------------

    with st.expander(
        "📜 7. Full YouTube Script",
        expanded=True,
    ):

        st.code(
            st.session_state.get(
                "script", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # THUMBNAIL
    # --------------------------------------------------------

    with st.expander(
        "🖼️ 8. Thumbnail Concepts"
    ):

        st.code(
            st.session_state.get(
                "thumbnail_ideas", ""
            ),
            language=None,
        )

        st.info(
            "Actual thumbnail image generation is "
            "currently paused."
        )

    # --------------------------------------------------------
    # SCENE PLAN
    # --------------------------------------------------------

    with st.expander(
        "🎬 9. Scene-by-Scene Plan"
    ):

        st.code(
            st.session_state.get(
                "scene_plan", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # YOUTUBE SHORT
    # --------------------------------------------------------

    with st.expander(
        "📱 10. YouTube Short"
    ):

        st.code(
            st.session_state.get(
                "shorts", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # INSTAGRAM REEL
    # --------------------------------------------------------

    with st.expander(
        "📸 11. Instagram Reel"
    ):

        st.code(
            st.session_state.get(
                "reel", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # REPURPOSED CONTENT
    # --------------------------------------------------------

    with st.expander(
        "🔄 12. Repurposed Content"
    ):

        st.code(
            st.session_state.get(
                "repurposed", ""
            ),
            language=None,
        )

    # --------------------------------------------------------
    # SEO
    # --------------------------------------------------------

    with st.expander(
        "🔍 13. SEO Analysis"
    ):

        st.code(
            st.session_state.get(
                "seo", ""
            ),
            language=None,
        )


# ============================================================
# SAVE / EXPORT
# ============================================================

if st.session_state.get("factory_completed"):

    st.divider()

    st.header("💾 Save & Export")

    current_content = get_current_content()

    col1, col2, col3 = st.columns(3)

    with col1:

        if st.button(
            "💾 Save Project",
            use_container_width=True,
        ):

            project = {
                "topic": topic,
                "audience": audience,
                "tone": tone,
                "video_length": video_length,
                "language": language,
                "content": current_content,
            }

            save_history(project)

            st.success(
                "Project saved to Content History!"
            )

    with col2:

        pdf_file = create_pdf(
            current_content
        )

        st.download_button(
            "📄 Download PDF",
            data=pdf_file,
            file_name="youtube_content.pdf",
            mime="application/pdf",
            use_container_width=True,
        )

    with col3:

        docx_file = create_docx(
            current_content
        )

        st.download_button(
            "📝 Download DOCX",
            data=docx_file,
            file_name="youtube_content.docx",
            mime=(
                "application/vnd.openxmlformats-officedocument"
                ".wordprocessingml.document"
            ),
            use_container_width=True,
        )


# ============================================================
# INDIVIDUAL CONTENT TOOLS
# ============================================================

st.divider()

st.header("🛠️ Individual Content Tools")

st.write(
    "Generate or regenerate one part of your content whenever you want."
)

# ------------------------------------------------------------
# VIDEO IDEAS
# ------------------------------------------------------------

if st.button(
    "💡 Generate Video Ideas",
    use_container_width=True,
):

    if not topic.strip():
        st.warning("Enter a topic first.")

    else:

        with st.spinner("Generating video ideas..."):

            result = generate_video_idea(
                topic,
                audience,
                tone,
                video_length,
                language,
            )

            st.session_state["ideas"] = result
            st.session_state["selected_idea"] = result

        st.subheader("💡 Video Ideas")
        st.code(result, language=None)


# ------------------------------------------------------------
# TITLES
# ------------------------------------------------------------

if st.button(
    "🎯 Generate Titles",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating titles..."):

        result = generate_titles(
            idea,
            audience,
            tone,
        )

        st.session_state["titles"] = result

    st.subheader("🎯 Titles")
    st.code(result, language=None)


# ------------------------------------------------------------
# HOOKS
# ------------------------------------------------------------

if st.button(
    "🪝 Generate Hooks",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating hooks..."):

        result = generate_hooks(
            idea,
            audience,
            tone,
            language,
        )

        st.session_state["hooks"] = result

    st.subheader("🪝 Hooks")
    st.code(result, language=None)


# ------------------------------------------------------------
# DESCRIPTION
# ------------------------------------------------------------

if st.button(
    "📝 Generate Description",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating description..."):

        result = generate_description(
            idea,
        )

        st.session_state["description"] = result

    st.subheader("📝 Description")
    st.code(result, language=None)


# ------------------------------------------------------------
# HASHTAGS
# ------------------------------------------------------------

if st.button(
    "#️⃣ Generate Hashtags",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating hashtags..."):

        result = generate_hashtags(
            idea,
        )

        st.session_state["hashtags"] = result

    st.subheader("#️⃣ Hashtags")
    st.code(result, language=None)


# ------------------------------------------------------------
# KEYWORDS
# ------------------------------------------------------------

if st.button(
    "🔑 Generate Keywords",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating keywords..."):

        result = generate_keywords(
            idea,
        )

        st.session_state["keywords"] = result

    st.subheader("🔑 Keywords")
    st.code(result, language=None)


# ------------------------------------------------------------
# FULL SCRIPT
# ------------------------------------------------------------

if st.button(
    "📜 Generate Full Script",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating full script..."):

        result = generate_script(
            idea,
            audience,
            tone,
            video_length,
            language,
        )

        st.session_state["script"] = result

    st.subheader("📜 Full Script")
    st.code(result, language=None)


# ------------------------------------------------------------
# THUMBNAIL CONCEPTS
# ------------------------------------------------------------

if st.button(
    "🖼️ Generate Thumbnail Concepts",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating thumbnail concepts..."):

        result = generate_thumbnail_ideas(
            idea,
        )

        st.session_state["thumbnail_ideas"] = result

    st.subheader("🖼️ Thumbnail Concepts")
    st.code(result, language=None)

    st.info(
        "Actual thumbnail image generation is currently paused."
    )


# ------------------------------------------------------------
# SCENE PLAN
# ------------------------------------------------------------

if st.button(
    "🎬 Generate Scene Plan",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating scene plan..."):

        result = generate_scene_plan(
            idea,
            video_length,
        )

        st.session_state["scene_plan"] = result

    st.subheader("🎬 Scene Plan")
    st.code(result, language=None)


# ------------------------------------------------------------
# YOUTUBE SHORT
# ------------------------------------------------------------

if st.button(
    "📱 Generate YouTube Short",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating YouTube Short..."):

        result = generate_youtube_short(
            idea,
        )

        st.session_state["shorts"] = result

    st.subheader("📱 YouTube Short")
    st.code(result, language=None)


# ------------------------------------------------------------
# INSTAGRAM REEL
# ------------------------------------------------------------

if st.button(
    "📸 Generate Instagram Reel",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Generating Instagram Reel..."):

        result = generate_instagram_reel(
            idea,
            audience,
            tone,
            language,
        )

        st.session_state["reel"] = result

    st.subheader("📸 Instagram Reel")
    st.code(result, language=None)


# ------------------------------------------------------------
# REPURPOSE CONTENT
# ------------------------------------------------------------

if st.button(
    "🔄 Repurpose Content",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    script = st.session_state.get("script", "")

    with st.spinner("Repurposing content..."):

        result = generate_repurposed_content(
            idea,
            script,
            audience,
            tone,
            language,
        )

        st.session_state["repurposed"] = result

    st.subheader("🔄 Repurposed Content")
    st.code(result, language=None)


# ------------------------------------------------------------
# SEO ANALYSIS
# ------------------------------------------------------------

if st.button(
    "🔍 Generate SEO Analysis",
    use_container_width=True,
):

    idea = st.session_state.get("selected_idea") or topic

    with st.spinner("Analyzing SEO..."):

        result = generate_seo_analysis(
            idea,
            st.session_state.get("titles", ""),
            st.session_state.get("keywords", ""),
            st.session_state.get("description", ""),
        )

        st.session_state["seo"] = result

    st.subheader("🔍 SEO Analysis")
    st.code(result, language=None)


# ============================================================
# CONTENT HISTORY
# ============================================================

# ============================================================
# CONTENT HISTORY
# ============================================================

st.divider()

st.header("📚 Content History")

history = load_history()

if not history:

    st.info(
        "No saved projects yet. "
        "Create and save a content package first."
    )

else:

    st.write(
        f"Saved projects: **{len(history)}**"
    )

    for index, project in enumerate(
        reversed(history)
    ):

        project_number = len(history) - index

        project_topic = project.get(
            "topic",
            "Untitled Project",
        )

        with st.expander(
            f"📁 {project_number}. "
            f"{project_topic}"
        ):

            st.write(
                f"**Audience:** "
                f"{project.get('audience', '')}"
            )

            st.write(
                f"**Style:** "
                f"{project.get('tone', '')}"
            )

            st.write(
                f"**Length:** "
                f"{project.get('video_length', '')}"
            )

            st.write(
                f"**Language:** "
                f"{project.get('language', '')}"
            )

            saved_content = project.get(
                "content",
                {}
            )

            st.subheader("💡 Video Idea")
            st.write(
                saved_content.get(
                    "idea", ""
                )
            )

            st.subheader("🎯 Titles")
            st.code(
                saved_content.get(
                    "titles", ""
                ),
                language=None,
            )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "🎬 AI Content Factory • "
    "Powered by Python + Streamlit + Ollama"
)